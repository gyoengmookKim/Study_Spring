package com.example.projectc;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.tabs.TabLayout;

public class Home extends Fragment {

    // 아래는 프레그먼트 선언한 것임
    Tab_All tab_all;
    Tab_opera tab_opera;
    Tab_Play tab_play;
    Tab_concert tab_concert;
    Tab_Muscial tab_muscial;
    Tab_Exhibition tab_exhibition;
    Fragment selectFragment= null;
    //  Home


    ImageView imageView;
    FrameLayout tab_contain;
    // 탭 찾기
    TabLayout tabs;

    MainActivity activity;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        activity = (MainActivity) getActivity();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.home, container, false);

        // 얘네는 내가 구현하고 싶은 프레그먼트들
        tab_all = new Tab_All();
        tab_concert = new Tab_concert();
        tab_opera = new Tab_opera();
        tab_play = new Tab_Play();
        tab_muscial = new Tab_Muscial();
        tab_exhibition = new Tab_Exhibition();


        // 처음 childFragment 지정
                                                               // 내가 넣고 싶은 프레그먼트의 자리(확보된자리),  tab_all 내가 붙이고 싶은거
        getChildFragmentManager().beginTransaction().replace(R.id.info_contain, tab_all).commit();
        //tabLayout을 선언하고 그 안에서 위치로 찾는게 빠름!
        tabs =  rootView.findViewById(R.id.tabs);
        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int position = tab.getPosition();
                switch (position) {
                    case 0:
                        getChildFragmentManager().beginTransaction().replace(R.id.info_contain, tab_all).commit();
                        break;
                    case 1:
                        getChildFragmentManager().beginTransaction().replace(R.id.info_contain, tab_muscial).commit();
                        break;
                    case 2:
                        getChildFragmentManager().beginTransaction().replace(R.id.info_contain, tab_opera).commit();
                        break;
                    case 3:
                        getChildFragmentManager().beginTransaction().replace(R.id.info_contain, tab_play).commit();
                        break;
                    case 4:
                        getChildFragmentManager().beginTransaction().replace(R.id.info_contain, tab_exhibition).commit();
                        break;
                    case 5 :
                        getChildFragmentManager().beginTransaction().replace(R.id.info_contain, tab_concert).commit();
                        break;


                }

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });





        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);




    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {



        return super.onOptionsItemSelected(item);
    }
}
