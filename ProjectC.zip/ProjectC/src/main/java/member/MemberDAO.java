package member;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;


@Repository
public class MemberDAO implements MemberService{
		@Autowired @Qualifier("cteam") SqlSession sql;
	
	// 생성자를 통해서 데이터베이스 드라이버를 선언해준다
	public MemberDAO() {
		try {
			Context context = new InitialContext();
			
		}catch(NamingException e) {
			e.getMessage();
		}
		
	}	
	
	// 8. 회원가입 : anJionCommand에서 값을 넘겨받는다
	public int anJoin(String id, String nickname, String password, String address, String kind, String email, String idnumber, String filename, String name) {
		
		/*
		 * String query =
		 * "insert into member(id, nickname, password, address, kind, email, idnumber, filename, name) "
		 * + " values('" + id + "', '" + nickname + "', '" + password + "', '" + address
		 * + "', '" + kind + "', '" + email + "', '" + idnumber + "', '"+filename
		 * +"', '"+name+"')";
		 */
		
		
		return 0;
		
	}
	
	// 8. 로그인 : anLoginCommand에서 값을 넘겨받는다
		public MemberVO member_login(HashMap<String, String> map) {
			return sql.selectOne("member.mapper.login", map);	
		}

		
		//9.로그인 정보 가져오기
		public ArrayList<MemberVO> anSelectMember() {
			
			// 데이터베이스와 연동하여 원하는 결과물을 얻는다.
			ArrayList<MemberVO> dtos = new ArrayList<MemberVO>();
			Connection connection = null;
			PreparedStatement prepareStatement = null;
			ResultSet resultSet = null;		
			
			/*
			 * try { connection = dataSource.getConnection(); String query =
			 * "select * from member" ; prepareStatement =
			 * connection.prepareStatement(query); resultSet =
			 * prepareStatement.executeQuery();
			 * 
			 * while (resultSet.next()) { String id = resultSet.getString("id"); String
			 * nickname = resultSet.getString("nickname"); String name =
			 * resultSet.getString("name"); String email = resultSet.getString("email");
			 * String address = resultSet.getString("address"); String filename =
			 * resultSet.getString("filename"); String idnumber =
			 * resultSet.getString("idnumber");
			 * 
			 * dtos.add(new MemberVO(id, nickname, address, email, idnumber, filename,
			 * name)); }
			 * 
			 * System.out.println("dtosSize : " + dtos.size());
			 * 
			 * } catch (Exception e) {
			 * 
			 * System.out.println(e.getMessage()); } finally { try {
			 * 
			 * if (resultSet != null) { resultSet.close(); } if (prepareStatement != null) {
			 * prepareStatement.close(); } if (connection != null) { connection.close(); }
			 * 
			 * } catch (Exception e) { e.printStackTrace(); } finally {
			 * 
			 * } }
			 */
			
			return dtos;
			
		}

		@Override
		public void member_join(MemberVO vo) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void member_delete(int id) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void member_update(MemberVO vo) {
			// TODO Auto-generated method stub
			
		}

}












