package member;

import java.sql.Date;

public class MemberVO {
    private String ID, NICKNAME, PASSWORD, ADDRESS, EMAIL, IDNUMBER, FILENAME, NAME, KIND;
    private Date JOINDATE;

	
	/*
	 * //회원 가입 할 때 public MemberVO(String iD, String nICKNAME, String pASSWORD,
	 * String aDDRESS, String eMAIL, String iDNUMBER, String fILENAME, String nAME,
	 * Date jOINDATE, String kIND ) { super(); ID = iD; NICKNAME = nICKNAME;
	 * PASSWORD = pASSWORD; ADDRESS = aDDRESS; EMAIL = eMAIL; IDNUMBER = iDNUMBER;
	 * FILENAME = fILENAME; NAME = nAME; JOINDATE = jOINDATE; KIND = kIND; }
	 */
	
	/*
	 * //로그인 할 때 암호 없이 멤버 정보 가져올 때 public MemberVO(String iD, String nICKNAME,
	 * String aDDRESS, String eMAIL, String iDNUMBER, String fILENAME, String nAME)
	 * { super(); ID = iD; NICKNAME = nICKNAME; ADDRESS = aDDRESS; EMAIL = eMAIL;
	 * IDNUMBER = iDNUMBER; FILENAME = fILENAME; NAME = nAME; }
	 */
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getNICKNAME() {
		return NICKNAME;
	}
	public void setNICKNAME(String nICKNAME) {
		NICKNAME = nICKNAME;
	}
	public String getPASSWORD() {
		return PASSWORD;
	}
	public void setPASSWORD(String pASSWORD) {
		PASSWORD = pASSWORD;
	}
	public String getADDRESS() {
		return ADDRESS;
	}
	public void setADDRESS(String aDDRESS) {
		ADDRESS = aDDRESS;
	}
	public String getEMAIL() {
		return EMAIL;
	}
	public void setEMAIL(String eMAIL) {
		EMAIL = eMAIL;
	}
	public String getIDNUMBER() {
		return IDNUMBER;
	}
	public void setIDNUMBER(String iDNUMBER) {
		IDNUMBER = iDNUMBER;
	}
	public String getFILENAME() {
		return FILENAME;
	}
	public void setFILENAME(String fILENAME) {
		FILENAME = fILENAME;
	}
	public String getNAME() {
		return NAME;
	}
	public void setNAME(String nAME) {
		NAME = nAME;
	}

	public String getKIND() {
		return KIND;
	}
	public void setKIND(String kIND) {
		KIND = kIND;
	}
	public Date getJOINDATE() {
		return JOINDATE;
	}
	public void setJOINDATE(Date jOINDATE) {
		JOINDATE = jOINDATE;
	}
    

	
    
    
    
}