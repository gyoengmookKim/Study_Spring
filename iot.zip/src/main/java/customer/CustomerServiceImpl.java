package customer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service	// @Service 어노테이션을 사용함으로써 해당 클래스가 서비스 레이어 클래스라는 것을 
			// 명확하게 할 수 있다.
public class CustomerServiceImpl implements CustomerService {

	@Autowired private CustomerDAO dao;
	// DB 에 접근하여 작업을 수행하기 위한 DAO를 메모리에 올려둔 주소들이 자동으로 연결 됨.
	
	@Override
	public void customer_insert(CustomerVO vo) {
		dao.customer_insert(vo);
	}

	@Override
	public List<CustomerVO> customer_list() {

		return dao.customer_list();
	}

	@Override
	public CustomerVO customer_detail(int id) {
		return dao.customer_detail(id);
	}

	@Override
	public void customer_update(CustomerVO vo) {
		dao.customer_update(vo);

	}

	@Override
	public void customer_delete(int id) {
		dao.customer_delete(id);
	}

}
