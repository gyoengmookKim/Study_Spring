package com.hanul.app.command;

import org.springframework.ui.Model;

public interface AnCommand {
	public void execute(Model model);
}
