package com.example.projectc;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.projectc.R;
import com.example.projectc.ShowAdapter;
import com.example.projectc.ShowDTO;

import java.util.ArrayList;

public class Tab_All  extends Fragment{
    GridView gridView;

    ShowAdapter adapter;
    ArrayList<ShowDTO> dtos;
    MainActivity activity;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.tab_all, container, false);

        dtos = new ArrayList<>();
        activity = (MainActivity) getActivity();
        gridView = rootView.findViewById(R.id.gridView);

        adapter = new ShowAdapter(activity, dtos);
        //어댑터에 생성한 메소드 addDto를 이용하여 dtos에 데이터를 추가한다.
        adapter.addDto(new ShowDTO("블랙핑크", R.drawable.singer1));
        adapter.addDto(new ShowDTO("마마", R.drawable.singer2));
        adapter.addDto(new ShowDTO("빅뱅", R.drawable.singer3));
        adapter.addDto(new ShowDTO("울랄라", R.drawable.singer4));
        adapter.addDto(new ShowDTO("AOMG", R.drawable.singer5));
        adapter.addDto(new ShowDTO("블랙핑크", R.drawable.singer1));
        adapter.addDto(new ShowDTO("마마", R.drawable.singer2));
        adapter.addDto(new ShowDTO("빅뱅", R.drawable.singer3));
        adapter.addDto(new ShowDTO("울랄라", R.drawable.singer4));
        adapter.addDto(new ShowDTO("AOMG", R.drawable.singer5));
        adapter.addDto(new ShowDTO("블랙핑크", R.drawable.singer1));
        adapter.addDto(new ShowDTO("마마", R.drawable.singer2));
        adapter.addDto(new ShowDTO("빅뱅", R.drawable.singer3));
        adapter.addDto(new ShowDTO("울랄라", R.drawable.singer4));
        adapter.addDto(new ShowDTO("AOMG", R.drawable.singer5));
        adapter.addDto(new ShowDTO("블랙핑크", R.drawable.singer1));
        adapter.addDto(new ShowDTO("마마", R.drawable.singer2));
        adapter.addDto(new ShowDTO("빅뱅", R.drawable.singer3));
        adapter.addDto(new ShowDTO("울랄라", R.drawable.singer4));
        adapter.addDto(new ShowDTO("AOMG", R.drawable.singer5));

        gridView.setAdapter(adapter);

        //리스트뷰는 아이템 클릭 이벤트를 제공해준다.
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ShowDTO dto = (ShowDTO) adapter.getItem(position);
                Toast.makeText(activity, "" + "선택 : " + position
                        + "\n제목 : " + dto.getTitle()
                        + "\n이미지 : " + dto.getRegId(), Toast.LENGTH_SHORT).show();
            }
        });


        return rootView;
    }


}
