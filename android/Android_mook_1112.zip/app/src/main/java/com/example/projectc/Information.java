package com.example.projectc;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.tabs.TabLayout;

public class Information extends Fragment {

    private static final String TAG = "main:Information";

    // 아래는 프레그먼트 선언한 것임
    Info_Musical info_musical;
    Info_Opera info_opera;
    Info_Play info_play;
    Info_Exhibition info_exhibition;
    Info_Concert info_concert;

    //  informaion

    FrameLayout tab_contain;

    // 탭 찾기
    TabLayout tabs;

    MainActivity activity;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        activity = (MainActivity) getActivity();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.information, container, false);

        // 얘네는 내가 구현하고 싶은 프레그먼트들
        info_musical = new Info_Musical();
        info_opera = new Info_Opera();
        info_play = new Info_Play();
        info_exhibition = new Info_Exhibition();
        info_concert = new Info_Concert();

        // 처음 childFragment 지정
        // 내가 넣고 싶은 프레그먼트의 자리(확보된자리),  tab_all 내가 붙이고 싶은거
        getChildFragmentManager().beginTransaction().replace(R.id.Main_info_cotain, info_musical).commit();
        //tabLayout을 선언하고 그 안에서 위치로 찾는게 빠름!
        tabs =  rootView.findViewById(R.id.tabs_Info);
        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int position = tab.getPosition();
                Log.d(TAG, "onTabSelected: " + position);

                switch (position) {
                    case 0:
                        getChildFragmentManager().beginTransaction().replace(R.id.Main_info_cotain, info_musical).commit();
                        break;
                    case 1:
                        getChildFragmentManager().beginTransaction().replace(R.id.Main_info_cotain, info_opera).commit();
                        break;
                    case 2:
                        getChildFragmentManager().beginTransaction().replace(R.id.Main_info_cotain, info_play).commit();
                        break;
                    case 3:
                        getChildFragmentManager().beginTransaction().replace(R.id.Main_info_cotain, info_exhibition).commit();
                        break;
                    case 4:
                        getChildFragmentManager().beginTransaction().replace(R.id.Main_info_cotain, info_concert).commit();
                        break;
                }

            }

            //탭이 선택되지 않았을 때
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            //탭이 다시 선택되었을 때때
            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);




    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {



        return super.onOptionsItemSelected(item);
    }
}
