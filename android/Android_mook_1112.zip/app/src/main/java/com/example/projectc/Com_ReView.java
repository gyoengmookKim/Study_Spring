package com.example.projectc;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class Com_ReView extends Fragment{
    ListView listView;

    Com_ReView_Adapter adapter;
    ArrayList<Com_ReView_DTO> dtos;
    CommunityActivity activity;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.com_review_list, container, false);

        dtos = new ArrayList<>();
        activity = (CommunityActivity) getActivity();
        listView = rootView.findViewById(R.id.re_list);

        adapter = new Com_ReView_Adapter(activity, dtos);
        //어댑터에 생성한 메소드 addDto를 이용하여 dtos에 데이터를 추가한다.
        adapter.addDto(new Com_ReView_DTO("kkk", "오페라 꿀잼", "내용 미침", "2021/11/01", 1));
        adapter.addDto(new Com_ReView_DTO("dkdks", "콘서트 개꿀잼", "내용 도랏", "2021/11/02", 2));

        listView.setAdapter(adapter);

        //리스트뷰는 아이템 클릭 이벤트를 제공해준다.
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Com_ReView_DTO dto = (Com_ReView_DTO) adapter.getItem(position);
                Toast.makeText(activity, "" + "선택 : " + position
                        + "\n제목 : " + dto.getTitle()
                        + "\n내용 : " + dto.getContent(), Toast.LENGTH_SHORT).show();
            }
        });


        return rootView;
    }


}
