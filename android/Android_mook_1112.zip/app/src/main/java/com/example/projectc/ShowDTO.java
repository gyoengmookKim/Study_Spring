package com.example.projectc;

import java.io.Serializable;

public class ShowDTO implements Serializable {
    private String title;
    private int regId;

    public ShowDTO(String tile, int regId) {
        this.title = tile;
        this.regId = regId;
    }

    public String getTitle() {
        return title;
    }

    public void setTile(String tile) {
        this.title = tile;
    }

    public int getRegId() {
        return regId;
    }

    public void setRegId(int regId) {
        this.regId = regId;
    }
    /*public ShowDTO(String name, String mobile, int age, int regId) {
        this.name = name;
        this.mobile = mobile;
        this.age = age;
        this.regId = regId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getRegId() {
        return regId;
    }

    public void setRegId(int regId) {
        this.regId = regId;
    }*/

}