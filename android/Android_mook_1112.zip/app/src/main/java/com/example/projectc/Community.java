package com.example.projectc;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Community extends Fragment {


    Button btn_review, btn_with, btn_QnA;
    MainActivity activity;
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        activity = (MainActivity)getActivity();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.community, container, false);

        rootView.findViewById(R.id.btn_review).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(getActivity(), Com_List_Activity.class);
                startActivity(intent);
            }
        });

        rootView.findViewById(R.id.review_plus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(getActivity(), Com_List_Activity.class);
                startActivity(intent);
            }
        });

        //44, 52번째 줄 엑티비티 생성요망
//-----------------------------------------------------------------------------------------------------
        rootView.findViewById(R.id.btn_with).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(getActivity(), Com_List_Activity.class);
                startActivity(intent);
            }
        });

        rootView.findViewById(R.id.with_plus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(getActivity(), Com_List_Activity.class);
                startActivity(intent);
            }
        });

        rootView.findViewById(R.id.btn_QnA).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(getActivity(), Com_List_Activity.class);
                startActivity(intent);
            }
        });

        rootView.findViewById(R.id.QnA_plus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(getActivity(), Com_List_Activity.class);
                startActivity(intent);
            }
        });
//-----------------------------------------------------------------------------------------------------
        return rootView;
    }

}
