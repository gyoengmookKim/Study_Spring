package com.example.projectc;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {




    // 여기부터는 위에 상단 탭--------------------------------------

    Toolbar toolbar;




    // 아래 네비게이션 바 !--------------------------------------------------------------
    // 여긴 네비게이션 fragment 임

    Home home;
    Information interest;
    Recommend recommend;
    More more;
    Community community;
    
    // 여기가 아래 네비게이션 바
    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);













        // 여기서 부터는 상단 탭 -----------------------


        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false);

        // 아래 네비게이션 bar 

        home = new Home();
        interest = new Information();
        recommend = new Recommend();
        more = new More();
        community = new Community();

        // 처음 메인화면 초기화
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.info_contain, home).commit();


        bottomNavigationView = findViewById(R.id.bottom_navi);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.home_tab:
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.info_contain, home).commit();

                        break;

                    case R.id.interest_tab:
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.info_contain, interest).commit();
                        toolbar.setTitle("공연정보");
                        break;

                    case R.id.recommend_tab:
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.info_contain, recommend).commit();
                        toolbar.setTitle("추천");
                        break;


                    case R.id.community_tab:_tab:
                        getSupportFragmentManager().beginTransaction().replace(R.id.info_contain, community).commit();
                        toolbar.setTitle("커뮤니티");


                        break;



                    case R.id.more_tab:
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.info_contain, more).commit();
                        toolbar.setTitle("더보기");
                        break;
                }

                return true;
            }
        });

    } //oncreate


    // 옵션바 옵션메뉴 붙인거--------------------------------------------------------------------------------------
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();

         inflater.inflate(R.menu.menu_top_option, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_search:
                startActivity(new Intent(this, Activity_Search.class));

        }


        return super.onOptionsItemSelected(item);
    }

}