package customer;

import java.util.List;

public interface CustomerService {

	// CRUD(Create / Read / Update / Delete)
	
	void customer_insert(CustomerVO vo);	// 고객 정보 저장 (Create, C)
	
	List<CustomerVO> customer_list();		// 전체 고객 목록 조회 (Read, R)
	
	CustomerVO customer_detail(int id);		// 1명(건)의 상세 내용 조회 (Read, R)
	
	void customer_update(CustomerVO vo);	// 고객 정보 변경 (Update, U) 
	
	void customer_delete(int id);			// 1명(건)의 고객 정보 삭제 (Delete, D)
	
}
