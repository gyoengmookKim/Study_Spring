package com.hanul.iot;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import customer.CustomerService;
import customer.CustomerServiceImpl;
import customer.CustomerVO;

@Controller
public class CustomerController {
	
	@Autowired private CustomerServiceImpl service;
	// @Autowired : 메모리에 올려둔 주소들이 자동으로 연결됨.
	
	// 고객 정보 삭제 처리
	@RequestMapping("/delete.cu")
	public String delete(int id, RedirectAttributes rttr) {
		
		// 선택한 고객 정보를 DB에서 삭제 후 목록 화면으로 연결
		service.customer_delete(id);
		
		rttr.addFlashAttribute("result", "deleteOK");
		return "redirect:list.cu";
		// 삭제 후 갱신된 목록 처리 -> list.jsp
	}
	
	
	// 고객 수정 정보 저장
	@RequestMapping("/update.cu")
	public String update(CustomerVO vo) {
		// 화면에서 입력한 수정 정보를 DB에 저장한 후 ....
		service.customer_update(vo);
		return "redirect:detail.cu?id=" + vo.getId();
		// 수정 이후 해당 고객(id)의 수정된 상세 정보 화면 요청
	}
	
	
	// 고객 정보 수정 화면 요청
	@RequestMapping("/modify.cu")
	public String modify(int id, Model model) {
		// 선택한 고객 정보를 DB에서 조회 (detail)
		model.addAttribute("vo", service.customer_detail(id));
		// 조회 내용을 model 에 담아 수정화면(modify.jsp)으로 이동
		return "customer/modify";
	}
	
	
	// 신규 고객 정보 저장처리
	@RequestMapping("/insert.cu")
	public String insert(CustomerVO vo) {
		service.customer_insert(vo);
		return "redirect:list.cu";	// 등록 이후 전체 회원 조회를 통해 갱신 필요
	}
	
	
	// 신규 고객 등록 화면 요청
	@RequestMapping("/new.cu")
	public String new_customer() {
		return "customer/new";
	}
	
	@RequestMapping("/detail.cu")
	public String customer_detail(int id, Model model) {
		model.addAttribute("vo", service.customer_detail(id));
		return "customer/detail";
	}
	
	
	@RequestMapping("/list.cu")
	public String list(HttpSession session, Model model) {
	
		session.setAttribute("category", "cu"); 
		// 카테고리 어트리뷰트에 cu 를 설정
		
//		List<CustomerVO> list = service.customer_list();
		
//		for (CustomerVO vo : list ) {
//			System.out.println(vo.getName());
//		}
		
//		model.addAttribute("list", list);
		model.addAttribute("list", service.customer_list());
		
		return "customer/list";
	}
}
