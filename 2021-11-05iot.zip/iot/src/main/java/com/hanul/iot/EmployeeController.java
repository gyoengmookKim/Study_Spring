package com.hanul.iot;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import employee.EmployeeServiceImpl;
import employee.EmployeeVO;

// 사원목록 페이지 처리 @Controller 생성
@Controller
public class EmployeeController {
	
	@Autowired private EmployeeServiceImpl service;

	// 선택한 사원의 상세 정보 조회 및 화면 출력
	@RequestMapping("/detail.hr")
	public String detail(int id, Model model) {
		
	// web 페이지에 출력하기 위하여 조회 결과 값을 vo 변수로 지정하여 detail.jsp 에 전달
		model.addAttribute("vo", service.employee_detail(id) );
		return "employee/detail";
	}
	
	
	// 사원목록 화면 요청
	@RequestMapping("/list.hr")
	public String list(HttpSession session, Model model, String dept_name) {
		session.setAttribute("category", "hr");
		
		// 사원이 소속된 부서명 목록을 조회해와 목록화면에 출력
		model.addAttribute("depts", service.employee_department() );
		model.addAttribute("dept_id", dept_name);
		// select 태그(name속성) 내 선택되어 있는 값(dept_name)
		
		if ( dept_name == null || dept_name.equals("all")) 
		// web 페이지에 출력하기 위하여 조회결과 값을 vo변수로 지정하여 list.jsp 에 전달
			model.addAttribute("list", service.employee_list() );
		else 
			// 특정 부서의 사원 정보 조회
			model.addAttribute("list", service.employee_list(dept_name)) ;
		return "employee/list";
	}

}
