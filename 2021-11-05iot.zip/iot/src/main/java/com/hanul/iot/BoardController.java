package com.hanul.iot;

import java.io.File;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import board.BoardPage;
import board.BoardServiceImpl;
import board.BoardVO;
import common.CommonService;
import member.MemberVO;

@Controller
public class BoardController {
	
	@Autowired private BoardServiceImpl service;
	@Autowired private BoardPage page;
	@Autowired private CommonService common;
	
	//방명록 글 수정 화면 요청
	@RequestMapping("/modify.bo")
	public String modify(int id, Model model) {
		
		model.addAttribute("vo", service.board_detail(id));
		
		return "board/modify";
	}
	
	
	//방명록 게시글 삭제처리
	@RequestMapping("/delete.bo")
	public String delete(int id, HttpSession session, Model model) {
		
	
		
		BoardVO vo = service.board_detail(id);
		String uuid = session.getServletContext().getRealPath("resources") + "/" + vo.getFilepath();
		
		// 파일명 또는 파일경로 있는지 판단 (없지 않다면) 
		if (vo.getFilename() != null) {
			// 디렉토리 또는에 대한 접근 권한을 가진 File 개체를 통해 파일 위치 할당
			File file = new File( uuid ); 
			// upload 폴더 내 file 이 존재한다면 삭제 처리
			if (file.exists()) file.delete();
		}
		service.board_delete(id);
		model.addAttribute("uri", "list.bo");
		model.addAttribute("page", page);
		
		return "board/redirect";
	}
	//새로고침해서 화면이동
	@RequestMapping()
	public String redirect() {
		
		return "";
	}
	
	
	//
	
	// 방명록 첨부파일 다운로드 요청
	@RequestMapping ("/download.bo")
	public void download(int id, HttpSession session, HttpServletResponse response ) {
		
		// 해당 글의 첨부파일 정보를 DB에서 조회해와 해당 파일을 서버로부터 다운로드 함.
		BoardVO vo = service.board_detail(id);
		common.fileDownload(vo.getFilename(), vo.getFilepath(), session, response);		
	}
	
	
	// 방명록 상세화면 요청
	@RequestMapping ("/detail.bo")
	public String detail(int id, Model model) {
		
		// 조회수 증가 처리
		service.board_read(id);
		
		// 해당 방명록 글을 DB에서 조회해와 상세화면에 출력
		model.addAttribute("vo", service.board_detail(id) );
		model.addAttribute("crlf", "\r\n");
		return "board/detail";
	}
	
	
	// 방명록 신규 저장 처리 요청
	@RequestMapping ("/insert.bo")
	public String insert(BoardVO vo, MultipartFile file, HttpSession session ) {
		
		// 첨부된 파일이 있다면
		if ( ! file.isEmpty()) {
			vo.setFilename(file.getOriginalFilename());
			vo.setFilepath( common.fileUpload("board", file, session) );
		}
		
		MemberVO member =  (MemberVO) session.getAttribute("loginInfo");
		vo.setWriter( member.getId() );
		
		// 화면에서 입력한 정보를 DB에 신규 저장한 후 목록화면 연결
		service.board_insert(vo);
		return "redirect:list.bo";
	}
	
	// 방명록 글쓰기 화면 요청
	@RequestMapping ("/new.bo")
	public String board() {
		return "board/new";
	}
	
	// 방명록 목록화면 요청
	@RequestMapping ("/list.bo")
	public String list(HttpSession session
			, String search, String keyword
			, @RequestParam (defaultValue = "10") int pageList
			, @RequestParam (defaultValue = "1") int curPage
			, @RequestParam (defaultValue = "list") String viewType
			, Model model) {
		
		session.setAttribute("category", "bo");
		
		// DB에서 방명록 정보를 조회해와 목록화면에 출력
		page.setCurPage(curPage);	// 현재 페이지를 담음
		
		page.setSearch(search);		// 검색 조건
		page.setKeyword(keyword);	// 검색어
		page.setPageList(pageList);	// 페이지당 보여질 글 목록 수
		page.setViewType(viewType);	// 게시판 형태
		model.addAttribute("page", service.board_list(page) );
		return "board/list";
	}
}
